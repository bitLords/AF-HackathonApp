import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";

import Card from "components/Card/Card.jsx";

class Typography extends Component {
  render() {
    return (
      <div className="content">
        <Grid fluid>
          <Row>
            <Col md={12}>
              <Card
                title="Near By Hospitals"

                content={
                  <div>
                    <div className="typo-line">
                      <h1>
                        <p className="category"> </p>

                      </h1>
                    </div>

                    <div className="typo-line">
                      <h2>
                        <p className="category"> </p>
                      </h2>
                    </div>
                    <div className="typo-line">
                      <h3>
                        <p className="category"> </p>

                      </h3>
                    </div>
                    <div className="typo-line">
                      <h4>
                        <p className="category"> </p>

                      </h4>
                    </div>
                    <div className="typo-line">
                      <h5>
                        <p className="category"> </p>

                      </h5>
                    </div>
                    <div className="typo-line">
                      <h6>
                        <p className="category"> </p>

                      </h6>
                    </div>
                    <div className="typo-line">
                      <p>
                        <span className="category"> </span>

                      </p>
                    </div>
                    <div className="typo-line">
                      <p className="category"> </p>
                      <blockquote>
                        <p>

                        </p>
                        <small> </small>
                      </blockquote>
                    </div>

                    <div className="typo-line">
                      <p className="category"></p>
                      <p className="text-muted">

                      </p>
                    </div>
                    <div className="typo-line">
                      {/* <!--
                                             there are also "text-info", "text-success", "text-warning", "text-danger" clases for the text
                                             --> */}
                      <p className="category"></p>
                      <p className="text-primary">

                      </p>
                      <p className="text-info">

                      </p>
                      <p className="text-success">

                      </p>
                      <p className="text-warning">

                      </p>
                      <p className="text-danger">

                      </p>
                    </div>

                    <div className="typo-line">
                      <h2>
                        <p className="category"> </p>
                         <br />
                        <small> </small>{" "}
                      </h2>
                    </div>
                  </div>
                }
              />
            </Col>
          </Row>
        </Grid>
      </div>
    );
  }
}

export default Typography;
