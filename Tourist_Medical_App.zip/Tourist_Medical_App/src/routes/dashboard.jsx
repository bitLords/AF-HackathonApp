import Dashboard from "views/Dashboard/Dashboard";
import UserProfile from "views/UserProfile/UserProfile";
import TableList from "views/TableList/TableList";
import Typography from "views/Typography/Typography";
import Icons from "views/Icons/Icons";
import Maps from "views/Maps/Maps";
import Notifications from "views/Notifications/Notifications";
import Upgrade from "views/Upgrade/Upgrade";
import Home from "../views/Home/Home";
import Laboratories from "../views/Laboratories/Laboratories";
import Pharmacies from "../views/Pharmacies/Pharmacies";

const dashboardRoutes = [
  { path: "/home", name: "Home", icon: "", component: Home },

  {
    path: "/user",
    name: "User Profile",
    icon: "",
    component: UserProfile
  },

  {
    path: "/typography",
    name: "Hospitals",
    icon: "",
    component: Typography
  },
  { path: "/laboratories", name: "Laboratories", icon: "", component: Laboratories },
  { path: "/pharmacies", name: "Pharmacies", icon: "", component: Pharmacies },
  { path: "/maps", name: "Maps", icon: "", component: Maps },
  {
    path: "/notifications",
    name: "Vehicles",
    icon: "",
    component: Notifications
  },

  { redirect: true, path: "/", to: "/dashboard", name: "Dashboard" }
];

export default dashboardRoutes;
