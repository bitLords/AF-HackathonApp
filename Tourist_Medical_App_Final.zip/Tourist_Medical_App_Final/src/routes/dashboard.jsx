import Dashboard from "views/Dashboard/Dashboard";
import UserProfile from "views/UserProfile/UserProfile";
import TableList from "views/TableList/TableList";
import Typography from "views/Typography/Typography";
import Icons from "views/Icons/Icons";
import Maps from "views/Maps/Maps";
import Notifications from "views/Notifications/Notifications";
import Upgrade from "views/Upgrade/Upgrade";
import Home from "../views/Home/Home";
import Laboratories from "../views/Laboratories/Laboratories";
import Pharmacies from "../views/Pharmacies/Pharmacies";
import Assistance from "../views/Assistance/Assistance";

const dashboardRoutes = [
  { path: "/home", name: "Home", icon: "pe-7s-keypad", component: Home },

  {
    path: "/user",
    name: "User Profile",
    icon: "pe-7s-id",
    component: UserProfile
  },

  {
    path: "/typography",
    name: "Hospitals",
    icon: "pe-7s-look",
    component: Typography
  },
  { path: "/laboratories", name: "Laboratories", icon: "pe-7s-eyedropper", component: Laboratories },
  { path: "/pharmacies", name: "Pharmacies", icon: "pe-7s-bandaid", component: Pharmacies },
  { path: "/maps", name: "Maps", icon: "pe-7s-map-2", component: Maps },

  {
    path: "/notifications",
    name: "Vehicles",
    icon: "pe-7s-car",
    component: Notifications
  },
  { path: "/assistance", name: "Assistance", icon: "pe-7s-user-female", component: Assistance },


    { redirect: true, path: "/", to: "/dashboard", name: "Dashboard" }
];

export default dashboardRoutes;
