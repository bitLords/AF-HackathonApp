import React, { Component } from "react";
import { Grid, Row, Col, Alert } from "react-bootstrap";

import Button from "components/CustomButton/CustomButton.jsx";

class Notifications extends Component {
  render() {
    return (
      <div className="content">
        <Grid fluid>
          <div className="card">
            <div className="header">
              <h4 className="title"><h1>Hire Vehicles</h1></h4>
              <p className="category">
              </p>
            </div>
            <div className="content">
              <Row>
                <Col md={6}>
                  <h4>Ambulance Service</h4>
                  <Alert bsStyle="info">
                    <span><h5><b>Are you in an Emergency situation?</b></h5></span>
                  </Alert>
                  <Alert bsStyle="info">

                    <span><h2>HOT LINE - <b>2345</b></h2></span>
                  </Alert>

                </Col>
                <Col md={6}>
                  <h4>Other Vehicles</h4>
                  <Alert bsStyle="info">
                    <span><h5><b>Do you need to hire a vehicle?</b></h5></span>
                  </Alert>
                  <Alert bsStyle="info">
                    <span><h2>HOT LINE - <b>5678</b></h2></span>
                  </Alert>
                </Col>
              </Row>
              <br />
              <br />
              <div className="places-buttons">
                <Row>
                  <Col md={6} mdOffset={3} className="text-center">
                    <h5>
                      Vehicle Types
                      <p className="category">Click to view details or book a ride</p>
                    </h5>
                  </Col>
                </Row>
                <Row>
                  <Col md={2} mdOffset={3}>
                    <Button
                      bsStyle="default"
                      block
                      onClick={() => this.props.handleClick("tl")}
                    >
                      Budget
                    </Button>
                  </Col>
                  <Col md={2}>
                    <Button
                      bsStyle="default"
                      block
                      onClick={() => this.props.handleClick("tc")}
                    >
                      Tuk
                    </Button>
                  </Col>
                  <Col md={2}>
                    <Button
                      bsStyle="default"
                      block
                      onClick={() => this.props.handleClick("tr")}
                    >
                      Buddy
                    </Button>
                  </Col>
                </Row>
                <Row>
                  <Col md={2} mdOffset={3}>
                    <Button
                      bsStyle="default"
                      block
                      onClick={() => this.props.handleClick("bl")}
                    >
                      Nano
                    </Button>
                  </Col>
                  <Col md={2}>
                    <Button
                      bsStyle="default"
                      block
                      onClick={() => this.props.handleClick("bc")}
                    >
                      Mini
                    </Button>
                  </Col>
                  <Col md={2}>
                    <Button
                      bsStyle="default"
                      block
                      onClick={() => this.props.handleClick("br")}
                    >
                      Car
                    </Button>
                  </Col>
                </Row>
              </div>
            </div>
          </div>
        </Grid>
      </div>
    );
  }
}

export default Notifications;
