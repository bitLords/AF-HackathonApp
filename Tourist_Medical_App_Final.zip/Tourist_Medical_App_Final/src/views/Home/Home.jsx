import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";

import Card from "components/Card/Card";
import { iconsArray } from "variables/Variables.jsx";
import avatar from "assets/img/faces/face-3.jpg"
import { UserCard } from "components/UserCard/UserCard.jsx";
import Button from "components/CustomButton/CustomButton.jsx";
import 'assets/img/faces/Home.jpg'
import { FormInputs } from "components/FormInputs/FormInputs.jsx";

class Home extends Component {
    render() {
        return (
            <div className="content">
                <Grid fluid>
                    <Row>
                        <Col md={12}>

                                    <span>
                    <h1>WE CARE.....

                        YOU TRAVEL.....</h1>
                    <br />

                  </span>

                            <div align={"center"}>
                            <FormInputs
                                ncols={["col-md-3"]}
                                proprieties={[
                                    {
                                        label: "UserName",
                                        type: "text",
                                        bsClass: "form-control",

                                    },

                                ]}
                            />

                            <FormInputs
                                ncols={["col-md-3"]}
                                proprieties={[
                                    {
                                        label: "Password",
                                        type: "text",
                                        bsClass: "form-control",

                                    },

                                ]}
                            />

                                <Button bsStyle="info" pullCenter fill type="submit">
                                    Login
                                </Button>
                                <div className="clearfix" />

                            </div>

                        </Col>
                    </Row>
                </Grid>
            </div>
        );
    }
}

export default Home;
