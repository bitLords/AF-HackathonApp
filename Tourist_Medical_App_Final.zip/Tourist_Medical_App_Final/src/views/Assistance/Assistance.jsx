import React, { Component } from "react";
import { Grid,
         Row,
         Col,
         FormGroup,
         ControlLabel,
         FormControl} from "react-bootstrap";

import Card from "components/Card/Card";
import { iconsArray } from "variables/Variables.jsx";

import { FormInputs } from "components/FormInputs/FormInputs.jsx";
import { UserCard } from "components/UserCard/UserCard.jsx";
import Button from "components/CustomButton/CustomButton.jsx";

import avatar from "assets/img/faces/face-3.jpg";


class Assistance extends Component {
    render() {
        return (
            <div className="content">
                <Grid fluid>
                    <Row>
                        <Col md={8}>
                            <Card
                                title="Assistance for your comfort"
                                content={
                                    <form>
                                        <FormInputs
                                            ncols={["col-md-3"]}
                                            proprieties={[

                                                {
                                                    label: "Gender",
                                                    type: "text",
                                                    bsClass: "form-control",
                                                    placeholder: "Male/Female",
                                                    defaultValue: "Male/Female"
                                                },

                                            ]}
                                        />
                                        <FormInputs
                                            ncols={["col-md-6"]}
                                            proprieties={[
                                                {
                                                    label: "Purpose",
                                                    type: "text",
                                                    bsClass: "form-control",
                                                    placeholder: "Purpose",
                                                    defaultValue: "Purpose"
                                                },

                                            ]}
                                        />
                                        <FormInputs
                                            ncols={["col-md-6"]}
                                            proprieties={[
                                                {

                                                    label: "Working Duration Per Day",
                                                    type: "text",
                                                    bsClass: "form-control",
                                                    placeholder: "Anticipated # of Working Hours",
                                                    defaultValue: "Anticipated # of Working Hours"
                                                }
                                            ]}
                                        />
                                        <FormInputs
                                            ncols={["col-md-6"]}
                                            proprieties={[
                                                {
                                                    label: "Language",
                                                    type: "text",
                                                    bsClass: "form-control",
                                                    placeholder: "Preferred Language",
                                                    defaultValue: "Preferred Language"
                                                }

                                            ]}
                                        />

                                        <Row>
                                            <Col md={12}>
                                                <FormGroup controlId="formControlsTextarea">
                                                    <ControlLabel>Qualifications</ControlLabel>
                                                    <FormControl
                                                        rows="5"
                                                        componentClass="textarea"
                                                        bsClass="form-control"
                                                        placeholder="Purpose for hiring....."
                                                        defaultValue="Purpose for hiring....."
                                                    />
                                                </FormGroup>
                                            </Col>
                                        </Row>
                                        <Button bsStyle="info" pullRight fill type="submit">
                                            Find
                                        </Button>
                                        <div className="clearfix" />
                                    </form>
                                }
                            />
                        </Col>

                    </Row>
                </Grid>>
            </div>
        );
    }
}

export default Assistance;
