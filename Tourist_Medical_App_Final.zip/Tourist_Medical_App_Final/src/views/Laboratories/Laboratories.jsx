import React, { Component } from "react";
import { Grid, Row, Col } from "react-bootstrap";

import Card from "components/Card/Card";
import { iconsArray } from "variables/Variables.jsx";

class Laboratories extends Component {
    render() {
        return (
            <div className="content">
                <Grid fluid>
                    <Row>
                        <Col md={12}>
                            <Card
                                title="Near By Medical Laboratories"
                                category=""
                                content={
                                    <div>

                                        <div className="typo-line">
                                            <p className="category">Asiri Laoratories</p>
                                            <blockquote>
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetuer adipiscing
                                                    elit, sed diam nonummy nibh euismod tincidunt ut </p>
                                                <p>
                                                    laoreet dolore magna aliquam erat volutpat. Ut wisi
                                                    enim ad minim veniam.
                                                </p>
                                                <small>24/7 service</small><br></br>
                                                <button class="btn btn-primary"> Call now +941234567</button>
                                            </blockquote>
                                        </div>


                                        <div className="typo-line">
                                            <p className="category">Sewana Labs</p>
                                            <blockquote>
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetuer adipiscing
                                                    elit, sed diam nonummy nibh euismod tincidunt ut </p>
                                                <p>
                                                    laoreet dolore magna aliquam erat volutpat. Ut wisi
                                                    enim ad minim veniam.
                                                </p>
                                                <small>24/7 service</small><br></br>
                                                <button class="btn btn-primary"> Call now +942345689</button>
                                            </blockquote>
                                        </div>


                                        <div className="typo-line">
                                            <p className="category">Colombo Laboratories</p>
                                            <blockquote>
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetuer adipiscing
                                                    elit, sed diam nonummy nibh euismod tincidunt ut </p>
                                                <p>
                                                    laoreet dolore magna aliquam erat volutpat. Ut wisi
                                                    enim ad minim veniam.
                                                </p>
                                                <small>24/7 service</small><br></br>
                                                <button class="btn btn-primary"> Call now +943456789</button>
                                            </blockquote>
                                        </div>

                                        <div className="typo-line">
                                            <p className="category">Amaya Labs</p>
                                            <blockquote>
                                                <p>
                                                    Lorem ipsum dolor sit amet, consectetuer adipiscing
                                                    elit, sed diam nonummy nibh euismod tincidunt ut </p>
                                                <p>
                                                    laoreet dolore magna aliquam erat volutpat. Ut wisi
                                                    enim ad minim veniam.
                                                </p>
                                                <small>24/7 service</small><br></br>
                                                <button class="btn btn-primary"> Call now +945678934</button>
                                            </blockquote>
                                        </div>


                                    </div>
                                }
                            />
                        </Col>
                    </Row>
                </Grid>
            </div>
        );
    }

}

export default Laboratories;
